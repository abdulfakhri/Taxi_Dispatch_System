<?php
$username = 'aidifxin_abfa';
$password = '!@#123qweasdzxc';
$connection = new PDO( 'mysql:host=localhost;dbname=aidifxin_dispatch', $username, $password );

?>