<?PHP
//Variables of the Job entry
   $v1="job1";
   $v2="job2";
   $v3="job3";
   $v4="job4";
   $v5="job5";
   $v6="job6";
   $v7="job7";
   $v8="job8";
   $v9="job9";
   $v10="job10";
   $v11="job11";
   $v12="job12";
   $v13="job13";
   $v14="job14";
   $v15="job15";
   $v16="job16";
   $v17="job17";
   $v18="job18";
   $v19="job19";
   $v20="job20";
   $v21="job21";
   $v22="job22";
   $v23="job23";
   $v24="job24";
   $v25="job25";
   $v26="job26";
   $v27="job27";
   $v28="job28";
   //End of Variables
  
  /* 
   car_id,
driver_name,
home_address,
username,
password,
driver_phone,
driving_license,
driver_level,
operator_license,
driver_email,
disp_id
*/
   $dv1="driver_name";
   $dv2="driver_phone";
   $dv3="driver_email";
   $dv4="home_address";
   $dv5="car_id";
   $dv6="driver_level";
   $dv7="driving_license";
   $dv8="operator_license";
   $dv9="username";
   $dv10="password";
   $dv11="company";
   $dbutton='createdriver'
   //vehicles
   
   /*
   $veh1="number";
   $veh2="call_sign";
   $veh3="passenger";
   $veh4="wheelchair";
   $veh5="bags";
   $veh6="type";
   $veh7="image";
   $veh8="color";
   $veh9="license_plate";
   $veh10="disp_id";
   */
     
  
   

?>