<style>
 .btn-talk {
  background-color: red;
  width: 100%;
  
  height: 30px;
  font-family: 'Roboto', sans-serif;
  font-size: 15px;
  color: #fff;
  border: 3px;
  border-radius: 10px;
  box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
}   
 .btn-talk-sm {
  background-color: red;
  width: 100%;
  padding: 2px;
  height: 30px;
  font-family: 'Roboto', sans-serif;
  font-size: 15px;
  color: #fff;
  border: 0px;
  border-radius: 3px;
  box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
} 
.btn-speak-sm {
  background-color: black;
  width: 50%;
  padding: ;
  height: ;
  font-family: 'Roboto', sans-serif;
  font-size: 15px;
  color: #fff;
  border: 0px;
  border-radius: 3px;
  box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
}
.btn-speak {
  background-color: ;
  width: 20%;
  padding: 2px;
  height: 30px;
  font-family: 'Roboto', sans-serif;
  font-size: 15px;
  color: #fff;
  border: 0px;
  border-radius: 3px;
  box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
}
.wrapper {
    text-align: center;
    
}

.button {
    position: absolute;
    top: 80%;
    bottom:10%;
    background-color: red;
    width: 30%;
  
  height: 50px;
  font-family: 'Roboto', sans-serif;
  font-size: 15px;
  color: #fff;
  border: 3px;
  border-radius: 10px;
  box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
}
html,body {
  border: 0;
  padding: 0;
  margin: 0;
  height: 100%;
}
.textarea {
  width: 100%;
  height: 70px;
  
  box-sizing: border-box;
  box-shadow: 0px 0px 18px rgba(0, 0, 0, 0.2);
  border: 4px solid #000;
  border-radius: 5px;
  background-color: #ffe6e6;
  font-size:15px;
  resize: none;
}
body {
  background: #000;
  font-size: 16px;
  background-color: #000;
  font-family: Arial;
  font-size: 18px;
  color:#fff;
  padding: 0px;
}

.simpletable {
  border: 1px solid #ffcccc;
  width: 100%;
}
.w3-bar-item{
    
}

th,tr,td {
  text-align: left;
  border: 1px solid #ffcccc;
  padding: 10px;
}
    
</style>