<?php 
if(isset($distance)){
 $distance;
 $price=30;
 $tf= $distance*$price;
 echo 'Distance:'.$distance;
 echo '<br>';
 echo 'Fare:'.$tf.'+'."$";
}
?>