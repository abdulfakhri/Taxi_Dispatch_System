<?php

date_default_timezone_set('America/New York');

//echo date("l jS \of F Y h:i:s A");
echo date("d/m/Y   h:i:sa");
?>