<?php
$databaseHost = 'localhost';
$databaseName = 'aidifxin_dispatch';
$databaseUsername = 'aidifxin_abfa';
$databasePassword = '!@#123qweasdzxc';
$conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
	
?>