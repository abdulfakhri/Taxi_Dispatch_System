<?php
$databaseHost = 'localhost';
$databaseName = 'bnsznyem_ice';
$databaseUsername = 'bnsznyem_abfa';
$databasePassword = '!@#123qweasdzxc';
$conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
///////////////////////////////////PDO////////////////////////////////////////////////////
$username = 'bnsznyem_abfa';
$password = '!@#123qweasdzxc';
$connPDO = new PDO( 'mysql:host=localhost;dbname=bnsznyem_ice', $username, $password ); 
	
?>