
<?PHP include("../c/c.php");?>
<?PHP include("n1-api.php");?>
<?PHP include("style.php");?>
<?PHP include("side.php");?>

       


        
        
          
            
            
            