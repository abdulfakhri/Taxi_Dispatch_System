<?php include ('../c/c.php');?>
<?php include ($nav);?>
<?php include ($createjobapi);?>
<?php include ('createjb.php');?>
<?php include('../v/menubar.php');?>
<?php include('../v/jobstableRows.php');?>
<?php include('../v/mapt.php');?>
<?php include('../v/livecamera.php');?>
