
<?PHP
$title="AiDispatchSys";
$name="";
$createjob="Create Job";
$top_contents_align="left";
$top_menu_align="right";

$mode=$_SESSION['mode'];

if($mode=="Dark"){
$colormodeTop="#262626";
$colormode="black";
$colormodeComponent="black";
$fontcolor="white"; 
    
}else if($mode=="Light"){

$colormode="white";
$colormodeComponent="white";
$fontcolor="black";     

}



$Search_Jobs="Search";
$Customers="Passengers";
$Alarms="Alarms";
$Messages="Messages";
$Alerts="Alerts";       
$Suspensions="Suspensions";      
$Preferences="Settings";       
$Vehiclces="Vehicles";
$Suspensions="Suspensions";
$Users="Drivers";       
    

?>
