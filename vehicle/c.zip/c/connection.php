<?php
$databaseHost = 'localhost';
$databaseName = 'bnsznyem_ice';
$databaseUsername = 'bnsznyem_abfa';
$databasePassword = '!@#123qweasdzxc';
$conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
	
?>