<?PHP
$title="aiDispatchSys";
$name="aiDispatchSys";
$createjob="Create Job";
$top_contents_align="right";
$top_menu_align="left";

$top_color="black";
$back="black";
$back_light="#0000b3";
$Search_Jobs="Search";
$Customers="Passengers";
$Alarms="Alarms";
$Messages="Messages";
$Alerts="Alerts";       
$Suspensions="Suspensions";      
$Preferences="Settings";       
$Vehiclces="Vehicles";
$Suspensions="Suspensions";
$Users="Drivers";
$Dispatch="Dispatch";
$History="Shift History";    
$Zones="Zones"; 
$JobView="Home";
$WhatsNew="WhatsNew";
$Training="How To Use App";
?>
